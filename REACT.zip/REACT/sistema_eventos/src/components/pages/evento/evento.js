import React, { useEffect, useState } from "react";
import { GetEventos } from "../../../services/ServiceEvento";


const Evento = () => {

    const [listaEventos, setListaEventos] = useState([]);

    useEffect(() => {
        GetEventos().then(res => setListaEventos(res.data))
        console.log('eventos', listaEventos)
    }, [])
    return (
        <>
            <div>
                <h2>Cadastro de Eventos</h2>
            </div>

            <div>
                <table className="table table-stripped">
                    <thead>
                        <tr>
                            <th>
                                ID_Evento
                            </th>
                            <th>
                                ID_Organizador
                            </th>
                        </tr>
                    </thead>
                </table>
            </div>
        </>
    );
}
export default Evento