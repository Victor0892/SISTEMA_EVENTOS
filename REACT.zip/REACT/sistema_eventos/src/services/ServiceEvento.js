import Api from "../helpers/api";

export async function GetEventos() {
    return await Api.get("/Evento")
}

export async function GetEventoById(id)
{
    return await Api.get(`/evento/${id}`);
    
}
