import Api from "../helpers/api";

export async function GetOrganizadores() 
{
    return await Api.get("/organizador")
}

export async function GetOrganizadorById(id)
{
    return await Api.get(`/organizador/${id}`);
}