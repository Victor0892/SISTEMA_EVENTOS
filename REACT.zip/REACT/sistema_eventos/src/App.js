import React from "react";
import Evento from "./components/pages/evento/evento";


const App = () => {
  

  return (
    <>
      <Evento></Evento>
    </>
  )
}

export default App;
